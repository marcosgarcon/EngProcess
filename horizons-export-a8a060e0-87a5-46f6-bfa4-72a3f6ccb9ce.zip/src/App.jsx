import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import MainLayout from '@/components/layout/MainLayout';
import MtmDashboard from '@/pages/MtmDashboard';
import MtmAnalysis from '@/pages/MtmAnalysis';
import Reports from '@/pages/Reports';
import Settings from '@/pages/Settings';
import SavedAnalyses from '@/pages/SavedAnalyses';
import { Toaster } from '@/components/ui/toaster';

function App() {
  const [activeTab, setActiveTab] = useState('analysis');
  const [analysisResult, setAnalysisResult] = useState(null);
  const [savedAnalyses, setSavedAnalyses] = useState([]);
  const [analysisParams, setAnalysisParams] = useState({
    lossRate: 5,
    timeAddition: 10,
    rhythmFactor: 100,
    fatigueSupplement: 4,
    personalSupplement: 5,
    monotonySupplement: 1,
    tmuToSeconds: 0.036,
  });

  useEffect(() => {
    const storedAnalyses = localStorage.getItem('savedAnalyses');
    if (storedAnalyses) {
      setSavedAnalyses(JSON.parse(storedAnalyses));
    }
    const storedParams = localStorage.getItem('analysisParams');
    if (storedParams) {
      setAnalysisParams(JSON.parse(storedParams));
    }
  }, []);

  const saveCurrentAnalysis = (name) => {
    if (!analysisResult) return;
    const newSavedAnalysis = {
      id: Date.now(),
      name: name || `Análise de ${new Date().toLocaleString('pt-BR')}`,
      date: new Date().toISOString(),
      data: analysisResult,
    };
    const updatedAnalyses = [...savedAnalyses, newSavedAnalysis];
    setSavedAnalyses(updatedAnalyses);
    localStorage.setItem('savedAnalyses', JSON.stringify(updatedAnalyses));
  };

  const deleteAnalysis = (id) => {
    const updatedAnalyses = savedAnalyses.filter(a => a.id !== id);
    setSavedAnalyses(updatedAnalyses);
    localStorage.setItem('savedAnalyses', JSON.stringify(updatedAnalyses));
  };

  const loadAnalysis = (analysisData) => {
    setAnalysisResult(analysisData);
    setActiveTab('dashboard');
  };

  const updateAnalysisParams = (newParams) => {
    setAnalysisParams(newParams);
    localStorage.setItem('analysisParams', JSON.stringify(newParams));
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <MtmDashboard analysisResult={analysisResult} saveCurrentAnalysis={saveCurrentAnalysis} />;
      case 'analysis':
        return <MtmAnalysis setAnalysisResult={setAnalysisResult} setActiveTab={setActiveTab} analysisParams={analysisParams} />;
      case 'reports':
        return <Reports analysisResult={analysisResult} />;
      case 'saved':
        return <SavedAnalyses savedAnalyses={savedAnalyses} deleteAnalysis={deleteAnalysis} loadAnalysis={loadAnalysis} />;
      case 'settings':
        return <Settings analysisParams={analysisParams} setAnalysisParams={updateAnalysisParams} />;
      default:
        return <MtmDashboard analysisResult={analysisResult} saveCurrentAnalysis={saveCurrentAnalysis} />;
    }
  };

  return (
    <>
      <Helmet>
        <title>EngProcess MTM - WM | Análise Inteligente</title>
        <meta name="description" content="Otimize linhas de produção com análise de tempos e métodos (MTM) assistida por IA. Faça upload de vídeos, receba cronoanálises e sugestões de melhoria." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
        <MainLayout activeTab={activeTab} setActiveTab={setActiveTab}>
          {renderContent()}
        </MainLayout>
        <Toaster />
      </div>
    </>
  );
}

export default App;