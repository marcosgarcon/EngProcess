import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { SlidersHorizontal, Percent, Timer, Save, Check, Upload, FileJson, Wind, Coffee, Smile } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

const Settings = ({ analysisParams, setAnalysisParams }) => {
  const [localParams, setLocalParams] = useState(analysisParams);
  const [isSaved, setIsSaved] = useState(false);
  const { toast } = useToast();
  const fileInputRef = useRef(null);

  const handleSave = () => {
    setAnalysisParams(localParams);
    setIsSaved(true);
    toast({
      title: "Configurações Salvas!",
      description: "Os novos parâmetros serão usados na próxima análise.",
    });
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleParamChange = (param, value) => {
    const numericValue = value === '' ? '' : Number(value);
    setLocalParams(prev => ({ ...prev, [param]: numericValue }));
  };

  const handleFileUploadClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file && file.type === "application/json") {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const json = JSON.parse(e.target.result);
          const expectedKeys = Object.keys(analysisParams);
          const loadedKeys = Object.keys(json);
          const isValid = expectedKeys.every(key => loadedKeys.includes(key) && typeof json[key] === 'number');

          if (isValid) {
            setLocalParams(json);
            toast({
              title: "Configurações Carregadas!",
              description: "Parâmetros do arquivo foram carregados. Clique em salvar para aplicar.",
            });
          } else {
            throw new Error("O arquivo JSON não contém todos os campos esperados ou os tipos estão incorretos.");
          }
        } catch (error) {
          toast({
            variant: "destructive",
            title: "Erro ao ler arquivo",
            description: error.message || "O formato do JSON é inválido.",
          });
        }
      };
      reader.readAsText(file);
    } else {
      toast({
        variant: "destructive",
        title: "Arquivo inválido",
        description: "Por favor, selecione um arquivo .json.",
      });
    }
    event.target.value = null;
  };

  return (
    <motion.div
      key="settings"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div className="glass-effect p-8 rounded-xl max-w-4xl mx-auto">
        <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
          <SlidersHorizontal className="text-blue-400" />
          Parâmetros de Cálculo
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
          
          <div>
            <Label htmlFor="rhythmFactor" className="flex items-center gap-2 mb-2 text-blue-300/80">
              <Wind className="w-4 h-4" /> Fator de Ritmo
            </Label>
            <div className="relative">
              <Input id="rhythmFactor" type="number" step="0.1" value={localParams.rhythmFactor} onChange={(e) => handleParamChange('rhythmFactor', e.target.value)} className="bg-blue-900/30 border-blue-500/30 pl-4 pr-8" placeholder="Ex: 100" />
              <span className="absolute inset-y-0 right-3 flex items-center text-blue-300/70">%</span>
            </div>
          </div>

          <div>
            <Label htmlFor="tmuToSeconds" className="flex items-center gap-2 mb-2 text-blue-300/80">
              <Timer className="w-4 h-4" /> Fator de Conversão (TMU → seg)
            </Label>
            <Input id="tmuToSeconds" type="number" step="0.001" value={localParams.tmuToSeconds} onChange={(e) => handleParamChange('tmuToSeconds', e.target.value)} className="bg-blue-900/30 border-blue-500/30" placeholder="Ex: 0.036" />
          </div>

          <div className="md:col-span-2 pt-4">
             <p className="font-semibold text-white">Suplementos por Concessões</p>
          </div>

          <div>
            <Label htmlFor="personalSupplement" className="flex items-center gap-2 mb-2 text-blue-300/80">
              <Coffee className="w-4 h-4" /> Necessidades Pessoais
            </Label>
            <div className="relative">
              <Input id="personalSupplement" type="number" step="0.1" value={localParams.personalSupplement} onChange={(e) => handleParamChange('personalSupplement', e.target.value)} className="bg-blue-900/30 border-blue-500/30 pl-4 pr-8" placeholder="Ex: 5" />
              <span className="absolute inset-y-0 right-3 flex items-center text-blue-300/70">%</span>
            </div>
          </div>

          <div>
            <Label htmlFor="fatigueSupplement" className="flex items-center gap-2 mb-2 text-blue-300/80">
              <Percent className="w-4 h-4" /> Fadiga
            </Label>
            <div className="relative">
              <Input id="fatigueSupplement" type="number" step="0.1" value={localParams.fatigueSupplement} onChange={(e) => handleParamChange('fatigueSupplement', e.target.value)} className="bg-blue-900/30 border-blue-500/30 pl-4 pr-8" placeholder="Ex: 4" />
              <span className="absolute inset-y-0 right-3 flex items-center text-blue-300/70">%</span>
            </div>
          </div>
          
          <div>
            <Label htmlFor="monotonySupplement" className="flex items-center gap-2 mb-2 text-blue-300/80">
              <Smile className="w-4 h-4" /> Monotonia
            </Label>
            <div className="relative">
              <Input id="monotonySupplement" type="number" step="0.1" value={localParams.monotonySupplement} onChange={(e) => handleParamChange('monotonySupplement', e.target.value)} className="bg-blue-900/30 border-blue-500/30 pl-4 pr-8" placeholder="Ex: 1" />
              <span className="absolute inset-y-0 right-3 flex items-center text-blue-300/70">%</span>
            </div>
          </div>

        </div>
      </div>

      <div className="glass-effect p-8 rounded-xl max-w-4xl mx-auto">
        <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
          <Upload className="text-blue-400" />
          Carregar Configurações
        </h2>
        <p className="text-blue-300/70 mb-6">
          Importe um arquivo de configuração (.json) para aplicar rapidamente um conjunto de parâmetros salvos.
        </p>
        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".json" className="hidden" />
        <Button onClick={handleFileUploadClick} variant="outline" className="w-full border-blue-500/30 text-blue-300 hover:bg-blue-600/20">
          <FileJson className="w-5 h-5 mr-2" />
          Carregar de Arquivo
        </Button>
      </div>

      <div className="max-w-4xl mx-auto flex justify-end">
        <Button onClick={handleSave} disabled={isSaved} className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 disabled:opacity-70">
          {isSaved ? <Check className="w-5 h-5 mr-2" /> : <Save className="w-5 h-5 mr-2" />}
          {isSaved ? 'Salvo!' : 'Salvar Todos os Parâmetros'}
        </Button>
      </div>
    </motion.div>
  );
};

export default Settings;