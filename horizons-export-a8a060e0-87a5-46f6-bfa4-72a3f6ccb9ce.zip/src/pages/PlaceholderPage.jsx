import React from 'react';
import { motion } from 'framer-motion';
import { Wrench } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const PlaceholderPage = ({ title, description, icon }) => {
  const { toast } = useToast();
  const IconComponent = LucideIcons[icon] || Wrench;

  return (
    <motion.div
      key={title}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="glass-effect p-12 rounded-xl text-center"
    >
      <div className="max-w-md mx-auto">
        <IconComponent className="w-16 h-16 text-blue-400 mx-auto mb-4" />
        <h3 className="text-2xl font-semibold text-white mb-4">
          {title}
        </h3>
        <p className="text-blue-300/70 mb-6">
          {description || "Esta seção está em desenvolvimento e será implementada em breve com funcionalidades avançadas."}
        </p>
        <Button 
          onClick={() => toast({
            title: `🚧 ${title} em desenvolvimento`,
            description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀",
            duration: 4000,
          })}
          className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600"
        >
          Solicitar Implementação
        </Button>
      </div>
    </motion.div>
  );
};

export default PlaceholderPage;