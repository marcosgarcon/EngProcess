import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

const Reports = ({ analysisResult }) => {
  const { toast } = useToast();

  const exportToPDF = () => {
    if (!analysisResult) return;

    const doc = new jsPDF();
    const { kpis, mtmTable, standardWorkInstruction, improvementSuggestions } = analysisResult;

    doc.setFontSize(22);
    doc.text("Relatório de Análise MTM - EngProcess MTM - WM", 14, 20);
    
    doc.setFontSize(12);
    doc.text(`Data de Geração: ${new Date().toLocaleDateString('pt-BR')}`, 14, 30);
    doc.text(`Desenvolvido por: Marcos Garcon (Analista de Qualidade)`, 14, 35);

    doc.autoTable({
        startY: 45,
        head: [['KPI', 'Valor', 'Unidade']],
        body: [
            ['TMU Total', kpis.totalTMU, 'TMU'],
            ['Tempo Padrão', kpis.standardTime.toFixed(2), 'seg'],
            ['Taxa de Perda Aplicada', kpis.paramsUsed?.lossRate ?? kpis.lossPercentage, '%'],
            ['Acréscimo de Tempo Aplicado', kpis.paramsUsed?.timeAddition ?? 'N/A', '%'],
        ],
        theme: 'grid',
        headStyles: { fillColor: [30, 58, 138] }
    });

    let finalY = doc.lastAutoTable.finalY + 10;
    doc.setFontSize(16);
    doc.text("Tabela de Análise MTM", 14, finalY);

    doc.autoTable({
      startY: finalY + 5,
      head: [['Passo', 'Descrição', 'Código MTM', 'TMU', 'Tempo (s)']],
      body: mtmTable.map(row => [row.step, row.description, row.mtmCode, row.tmu, row.time]),
      theme: 'grid',
      headStyles: { fillColor: [30, 58, 138] }
    });

    finalY = doc.lastAutoTable.finalY + 10;
    doc.setFontSize(16);
    doc.text("Instrução de Trabalho Padronizado", 14, finalY);
    doc.setFontSize(10);
    doc.text(standardWorkInstruction.map(l => `- ${l}`).join('\n'), 14, finalY + 7, { maxWidth: 180 });

    finalY = doc.autoTable.previous.finalY > finalY ? doc.autoTable.previous.finalY + 15 : finalY + 40;
    doc.setFontSize(16);
    doc.text("Sugestões de Melhoria", 14, finalY);
    
    const suggestionsBody = improvementSuggestions.map(s => [s.title, s.description]);
    doc.autoTable({
        startY: finalY + 5,
        head: [['Título', 'Descrição']],
        body: suggestionsBody,
        theme: 'grid',
        headStyles: { fillColor: [30, 58, 138] }
    });

    doc.save("EngProcess_Relatorio_MTM.pdf");
    toast({ title: "Sucesso!", description: "Relatório PDF exportado." });
  };

  const exportToExcel = () => {
    if (!analysisResult) return;

    const { kpis, mtmTable, standardWorkInstruction, improvementSuggestions } = analysisResult;

    const wb = XLSX.utils.book_new();

    const ws_kpis = XLSX.utils.json_to_sheet([
      { KPI: 'TMU Total', Valor: kpis.totalTMU, Unidade: 'TMU' },
      { KPI: 'Tempo Padrão', Valor: kpis.standardTime, Unidade: 'seg' },
      { KPI: 'Taxa de Perda Aplicada', Valor: kpis.paramsUsed?.lossRate ?? kpis.lossPercentage, Unidade: '%' },
      { KPI: 'Acréscimo de Tempo Aplicado', Valor: kpis.paramsUsed?.timeAddition ?? 'N/A', Unidade: '%' },
    ]);
    XLSX.utils.book_append_sheet(wb, ws_kpis, "KPIs");

    const ws_mtm = XLSX.utils.json_to_sheet(mtmTable);
    XLSX.utils.book_append_sheet(wb, ws_mtm, "Tabela MTM");

    const ws_instructions = XLSX.utils.json_to_sheet(standardWorkInstruction.map(item => ({ 'Instrução': item })));
    XLSX.utils.book_append_sheet(wb, ws_instructions, "Instruções de Trabalho");

    const ws_suggestions = XLSX.utils.json_to_sheet(improvementSuggestions);
    XLSX.utils.book_append_sheet(wb, ws_suggestions, "Sugestões de Melhoria");

    XLSX.writeFile(wb, "EngProcess_Relatorio_MTM.xlsx");
    toast({ title: "Sucesso!", description: "Relatório Excel exportado." });
  };

  if (!analysisResult) {
    return (
        <motion.div
            key="no-report-data"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-effect p-12 rounded-xl text-center flex flex-col items-center justify-center h-full"
        >
            <AlertTriangle className="w-16 h-16 text-yellow-400 mb-4" />
            <h2 className="text-2xl font-semibold text-white mb-2">Nenhuma análise para relatar</h2>
            <p className="text-blue-300/70 max-w-md">
                Para gerar relatórios, por favor, realize uma análise na página de 'Análise MTM' primeiro.
            </p>
        </motion.div>
    );
  }

  return (
    <motion.div
      key="reports"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div className="glass-effect p-6 rounded-xl">
        <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
            <Download className="text-blue-400" />
            Exportar Relatório Completo
        </h2>
        <p className="text-blue-300/70 mb-6">
            Exporte os resultados completos da sua última análise para um arquivo PDF ou Excel para manter um histórico offline e compartilhar com sua equipe.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
            <Button onClick={exportToPDF} className="flex-1 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600">
                <FileText className="w-5 h-5 mr-2" />
                Exportar para PDF
            </Button>
            <Button onClick={exportToExcel} className="flex-1 bg-gradient-to-r from-sky-600 to-sky-500 hover:from-sky-700 hover:to-sky-600">
                <FileText className="w-5 h-5 mr-2" />
                Exportar para Excel
            </Button>
        </div>
      </div>

      <div className="glass-effect p-6 rounded-xl">
        <h3 className="text-xl font-semibold text-white mb-4">Pré-visualização da Análise</h3>
        <div className="space-y-4">
            <h4 className="font-semibold text-blue-300">KPIs Principais</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="p-3 bg-blue-900/30 rounded-lg">
                    <p className="text-sm text-blue-300/80">TMU Total</p>
                    <p className="text-2xl font-bold">{analysisResult.kpis.totalTMU}</p>
                </div>
                <div className="p-3 bg-blue-900/30 rounded-lg">
                    <p className="text-sm text-blue-300/80">Tempo Padrão</p>
                    <p className="text-2xl font-bold">{analysisResult.kpis.standardTime.toFixed(1)}s</p>
                </div>
                <div className="p-3 bg-blue-900/30 rounded-lg">
                    <p className="text-sm text-blue-300/80">Perda</p>
                    <p className="text-2xl font-bold">{analysisResult.kpis.lossPercentage.toFixed(1)}%</p>
                </div>
                <div className="p-3 bg-blue-900/30 rounded-lg">
                    <p className="text-sm text-blue-300/80">Otimização</p>
                    <p className="text-2xl font-bold">{analysisResult.kpis.optimizationPotential.toFixed(1)}%</p>
                </div>
            </div>
        </div>
      </div>
    </motion.div>
  );
};

export default Reports;