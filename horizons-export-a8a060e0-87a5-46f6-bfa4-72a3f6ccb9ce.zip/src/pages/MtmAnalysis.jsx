import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UploadCloud, Film, Bot, BrainCircuit, X, ClipboardList, Lightbulb, BarChart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const MtmAnalysis = ({ setAnalysisResult, setActiveTab, analysisParams }) => {
  const [videoFile, setVideoFile] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [currentAnalysis, setCurrentAnalysis] = useState(null);
  const videoRef = useRef(null);
  const { toast } = useToast();

  const generateMockAnalysis = (params) => {
    const baseTMU = 1388;
    
    const timeWithRhythm = baseTMU * (params.rhythmFactor / 100);
    
    const totalSupplement = params.fatigueSupplement + params.personalSupplement + params.monotonySupplement;
    const timeWithSupplement = timeWithRhythm * (1 + totalSupplement / 100);

    const standardTimeSeconds = timeWithSupplement * params.tmuToSeconds;

    return {
      kpis: {
        totalTMU: Math.round(baseTMU),
        standardTime: standardTimeSeconds,
        lossPercentage: params.lossRate,
        optimizationPotential: 12.1,
        paramsUsed: params,
      },
      mtmTable: [
        { id: 1, step: 1, description: "Alcançar a peça A", mtmCode: "R30B", tmu: 15.6, time: 0.56 },
        { id: 2, step: 2, description: "Pegar a peça A", mtmCode: "G1A", tmu: 2.0, time: 0.07 },
        { id: 3, step: 3, description: "Mover peça A para gabarito", mtmCode: "M30B", tmu: 16.2, time: 0.58 },
        { id: 4, step: 4, description: "Posicionar peça A no gabarito", mtmCode: "P1SE", tmu: 5.6, time: 0.20 },
        { id: 5, step: 5, description: "Alcançar a ferramenta B", mtmCode: "R20C", tmu: 12.2, time: 0.44 },
        { id: 6, step: 6, description: "Pegar ferramenta B", mtmCode: "G1A", tmu: 2.0, time: 0.07 },
        { id: 7, step: 7, description: "Mover ferramenta para peça A", mtmCode: "M20C", tmu: 13.5, time: 0.49 },
        { id: 8, step: 8, description: "Fixar peça com ferramenta", mtmCode: "AP2", tmu: 16.2, time: 0.58 },
        { id: 9, step: 9, description: "Soltar ferramenta", mtmCode: "RL1", tmu: 2.0, time: 0.07 },
      ],
      standardWorkInstruction: [
        "O operador alcança a peça A na caixa de suprimentos com a mão direita.",
        "Pega a peça A com os dedos.",
        "Move a peça A até a área de montagem e a posiciona no gabarito.",
        "Alcança a ferramenta de fixação B com a mão esquerda.",
        "Pega a ferramenta B e a move em direção à peça A.",
        "Aplica pressão com a ferramenta para fixar a peça A no local.",
        "Solta a ferramenta e a retorna para a posição de descanso.",
      ],
      improvementSuggestions: [
        { title: "Otimizar Layout", description: "Posicionar a caixa de suprimentos (peça A) mais perto do gabarito para reduzir o tempo de 'Alcançar' (R30B -> R15B). Potencial de economia: 8 TMU." },
        { title: "Usar Ferramenta Magnética", description: "Substituir o 'Pegar' (G1A) por um movimento de contato para reduzir o tempo de ciclo. Potencial de economia: 1.7 TMU." },
        { title: "Implementar Gabarito de Encaixe Rápido", description: "Simplificar a operação 'Posicionar' (P1SE -> P1NSE) para eliminar a necessidade de alinhamento preciso. Potencial de economia: 3.9 TMU." },
      ]
    };
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('video/')) {
      setVideoFile(file);
      setAnalysisComplete(false);
      setAnalysisResult(null);
      setCurrentAnalysis(null);
    } else {
      toast({
        variant: "destructive",
        title: "Arquivo inválido",
        description: "Por favor, selecione um arquivo de vídeo.",
        duration: 4000,
      });
    }
  };

  const handleRemoveVideo = () => {
    setVideoFile(null);
    setAnalysisComplete(false);
    setAnalysisResult(null);
    setCurrentAnalysis(null);
    if(videoRef.current) {
        videoRef.current.value = "";
    }
  };

  const handleAnalyze = () => {
    if (!videoFile) {
      toast({
        variant: "destructive",
        title: "Nenhum vídeo selecionado",
        description: "Faça o upload de um vídeo para iniciar a análise.",
        duration: 4000,
      });
      return;
    }
    setIsAnalyzing(true);
    setAnalysisComplete(false);
    toast({
      title: "Análise em progresso...",
      description: "A IA está processando o vídeo com os parâmetros definidos. 🤖",
      duration: 8000,
    });
    
    setTimeout(() => {
        const mockResult = generateMockAnalysis(analysisParams);
        setIsAnalyzing(false);
        setAnalysisResult(mockResult);
        setCurrentAnalysis(mockResult);
        setAnalysisComplete(true);
        toast({
            title: "Análise Concluída!",
            description: "A IA finalizou a análise do processo. Confira os resultados.",
            duration: 5000,
        });
    }, 7000);
  };

  const videoURL = videoFile ? URL.createObjectURL(videoFile) : null;

  return (
    <motion.div
      key="analysis"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <div className="glass-effect p-6 rounded-xl flex flex-col space-y-4">
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Film className="text-blue-400" />
            1. Upload e Análise de Vídeo
          </h2>
          {!videoFile ? (
            <div className="flex-grow flex items-center justify-center">
              <label htmlFor="video-upload" className="video-upload-dropzone w-full">
                <UploadCloud className="w-16 h-16 text-blue-400 mb-4" />
                <span className="text-white font-semibold">Arraste e solte o vídeo aqui</span>
                <span className="text-blue-300/70 mt-1">ou clique para selecionar</span>
                <input id="video-upload" type="file" accept="video/*" className="hidden" onChange={handleFileChange} ref={videoRef} />
              </label>
            </div>
          ) : (
            <>
              <div className="relative">
                 <video src={videoURL} controls className="w-full rounded-lg aspect-video bg-black"></video>
                 <Button variant="destructive" size="icon" className="absolute top-2 right-2 h-8 w-8" onClick={handleRemoveVideo}>
                    <X className="h-4 w-4" />
                 </Button>
              </div>
              <p className="text-blue-300/80 text-sm truncate">Arquivo: {videoFile.name}</p>
              <Button onClick={handleAnalyze} disabled={isAnalyzing || analysisComplete} className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 disabled:opacity-50">
                {isAnalyzing ? ( <><BrainCircuit className="w-5 h-5 mr-2 animate-pulse" /> Analisando com IA...</>
                ) : analysisComplete ? ( <><Bot className="w-5 h-5 mr-2" /> Análise Concluída</>
                ) : ( <><Bot className="w-5 h-5 mr-2" /> Iniciar Análise MTM com IA</> )}
              </Button>
            </>
          )}
        </div>

        <AnimatePresence>
        {analysisComplete && (
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="glass-effect p-6 rounded-xl space-y-4"
            >
                <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                    <BarChart className="text-blue-400" />
                    Resultados e Melhorias
                </h2>
                <div className="p-4 border-2 border-dashed border-blue-400/30 rounded-lg text-center">
                    <p className="text-blue-300/80">A análise da IA está pronta. Veja os KPIs no Dashboard ou exporte um relatório detalhado.</p>
                </div>
                 <Button onClick={() => setActiveTab('dashboard')} className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600">
                    <BarChart className="w-5 h-5 mr-2" /> Ver Dashboard de KPIs
                </Button>
                <Button onClick={() => setActiveTab('reports')} variant="outline" className="w-full border-blue-500/30 text-blue-300 hover:bg-blue-600/20">
                    <ClipboardList className="w-5 h-5 mr-2" /> Ir para Relatórios
                </Button>
            </motion.div>
        )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {analysisComplete && currentAnalysis && (
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="space-y-8"
            >
                <div className="glass-effect p-6 rounded-xl">
                    <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                        <ClipboardList className="text-blue-400" />
                        Instrução de Trabalho Padronizado (Gerada por IA)
                    </h2>
                    <ul className="space-y-2 list-decimal list-inside text-blue-300/90">
                        {currentAnalysis.standardWorkInstruction.map((item, index) => (
                            <li key={index}>{item}</li>
                        ))}
                    </ul>
                </div>
                
                <div className="glass-effect p-6 rounded-xl">
                    <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                        <Lightbulb className="text-yellow-400" />
                        Sugestões de Melhoria (Geradas por IA)
                    </h2>
                    <div className="space-y-4">
                        {currentAnalysis.improvementSuggestions.map((item, index) => (
                           <div key={index} className="p-4 rounded-lg bg-blue-900/30">
                               <h3 className="font-semibold text-white">{item.title}</h3>
                               <p className="text-blue-300/80 text-sm">{item.description}</p>
                           </div>
                        ))}
                    </div>
                </div>
            </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default MtmAnalysis;