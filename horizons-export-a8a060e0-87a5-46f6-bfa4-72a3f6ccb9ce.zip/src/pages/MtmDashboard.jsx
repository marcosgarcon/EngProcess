import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Clock,
  Zap,
  TrendingDown,
  Target,
  BarChart,
  PieChart,
  Lightbulb,
  AlertTriangle,
  Save,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const KpiCard = ({ icon: Icon, title, value, unit, color, index }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.1 }}
    className="glass-effect p-6 rounded-xl card-hover flex flex-col"
  >
    <div className="flex items-start justify-between mb-4">
      <div className={`p-2 rounded-lg bg-${color}-500/20`}>
        <Icon className={`w-8 h-8 text-${color}-400`} />
      </div>
    </div>
    <div className="mt-auto">
      <span className="text-blue-300/80 text-sm font-medium">{title}</span>
      <p className="text-3xl font-bold text-white">
        {value} <span className="text-xl font-medium text-blue-300/80">{unit}</span>
      </p>
    </div>
  </motion.div>
);

const MtmDashboard = ({ analysisResult, saveCurrentAnalysis }) => {
  const { toast } = useToast();
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    const analysisName = `Análise - ${new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })}`;
    saveCurrentAnalysis(analysisName);
    setIsSaved(true);
    toast({
      title: "Análise Salva!",
      description: `A análise "${analysisName}" foi salva com sucesso.`,
    });
    setTimeout(() => setIsSaved(false), 3000);
  };

  if (!analysisResult) {
    return (
        <motion.div
            key="no-data"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-effect p-12 rounded-xl text-center flex flex-col items-center justify-center h-full"
        >
            <AlertTriangle className="w-16 h-16 text-yellow-400 mb-4" />
            <h2 className="text-2xl font-semibold text-white mb-2">Nenhuma análise encontrada</h2>
            <p className="text-blue-300/70 max-w-md">
                Para visualizar o dashboard de KPIs, por favor, realize uma análise na página de 'Análise MTM' primeiro.
            </p>
        </motion.div>
    );
  }

  const { kpis } = analysisResult;
  const kpiData = [
    { title: "TMU Total", value: kpis.totalTMU.toLocaleString('pt-BR'), unit: "TMU", icon: Clock, color: 'blue' },
    { title: "Tempo Padrão", value: kpis.standardTime.toFixed(2), unit: "seg", icon: Zap, color: 'purple' },
    { title: "Perda Identificada", value: kpis.lossPercentage.toFixed(1), unit: "%", icon: TrendingDown, color: 'yellow' },
    { title: "Potencial de Otimização", value: kpis.optimizationPotential.toFixed(1), unit: "%", icon: Target, color: 'green' }
  ];

  return (
    <motion.div
      key="mtm-dashboard-data"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-8"
    >
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaved} className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 disabled:opacity-70">
          {isSaved ? <Check className="w-5 h-5 mr-2" /> : <Save className="w-5 h-5 mr-2" />}
          {isSaved ? 'Análise Salva!' : 'Salvar Análise'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => (
          <KpiCard key={kpi.title} {...kpi} index={index} />
        ))}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-effect p-6 rounded-xl">
           <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
            <BarChart className="text-blue-400" />
            Análise de Pareto de Gargalos
          </h3>
          <div className="h-64 flex items-center justify-center text-center border-2 border-dashed border-blue-400/30 rounded-lg">
            <p className="text-blue-300/70">Gráfico de Pareto será renderizado aqui com base nos dados.</p>
          </div>
        </div>

        <div className="glass-effect p-6 rounded-xl">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
            <PieChart className="text-blue-400" />
            Distribuição de Tempo
          </h3>
          <div className="h-64 flex items-center justify-center text-center border-2 border-dashed border-blue-400/30 rounded-lg">
             <p className="text-blue-300/70">Gráfico de Pizza será renderizado aqui.</p>
          </div>
        </div>
      </div>
      
       <div className="glass-effect p-6 rounded-xl">
           <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
            <Lightbulb className="text-yellow-400" />
            Sugestões de Melhoria da IA
          </h3>
          <div className="space-y-3">
             {analysisResult.improvementSuggestions.map((suggestion, index) => (
                <motion.div 
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="p-3 rounded-lg bg-blue-900/30"
                >
                    <h4 className="font-semibold text-white">{suggestion.title}</h4>
                    <p className="text-blue-300/80 text-sm">{suggestion.description}</p>
                </motion.div>
             ))}
          </div>
        </div>
    </motion.div>
  );
};

export default MtmDashboard;