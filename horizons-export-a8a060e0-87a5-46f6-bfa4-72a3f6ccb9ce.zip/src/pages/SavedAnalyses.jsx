import React from 'react';
import { motion } from 'framer-motion';
import { FolderClock, AlertTriangle, Trash2, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const SavedAnalyses = ({ savedAnalyses, deleteAnalysis, loadAnalysis }) => {
  const { toast } = useToast();

  const handleDelete = (id) => {
    deleteAnalysis(id);
    toast({
      title: "Análise Excluída",
      description: "A análise selecionada foi removida.",
      variant: "destructive"
    });
  };

  const handleLoad = (analysis) => {
    loadAnalysis(analysis.data);
    toast({
      title: "Análise Carregada",
      description: `A análise "${analysis.name}" foi carregada no dashboard.`,
    });
  };

  if (savedAnalyses.length === 0) {
    return (
      <motion.div
        key="no-saved-data"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-effect p-12 rounded-xl text-center flex flex-col items-center justify-center h-full"
      >
        <FolderClock className="w-16 h-16 text-blue-400 mb-4" />
        <h2 className="text-2xl font-semibold text-white mb-2">Nenhuma análise salva</h2>
        <p className="text-blue-300/70 max-w-md">
          Você ainda não salvou nenhuma análise. Após concluir uma análise no dashboard, clique em "Salvar Análise" para guardá-la aqui.
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      key="saved-analyses"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {savedAnalyses.map((analysis, index) => (
        <motion.div
          key={analysis.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1 }}
          className="glass-effect p-4 rounded-xl flex items-center justify-between"
        >
          <div>
            <p className="font-semibold text-white">{analysis.name}</p>
            <p className="text-sm text-blue-300/70">
              Salvo em: {new Date(analysis.date).toLocaleString('pt-BR')}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="border-blue-500/30 text-blue-300 hover:bg-blue-600/20" onClick={() => handleLoad(analysis)}>
              <Eye className="w-5 h-5" />
            </Button>
            <Button variant="destructive" size="icon" onClick={() => handleDelete(analysis.id)}>
              <Trash2 className="w-5 h-5" />
            </Button>
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default SavedAnalyses;