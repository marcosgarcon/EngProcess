import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Header = ({ activeTab }) => {
  const { toast } = useToast();

  const handleCreateAnalysis = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "A criação de uma nova análise será implementada em breve. Por enquanto, utilize a página de Análise MTM. 🚀",
      duration: 4000,
    });
  };

  const pageTitles = {
    dashboard: {
      title: 'Dashboard de Análise',
      subtitle: 'KPIs e métricas da sua última análise de processo'
    },
    analysis: {
      title: 'Análise de Tempos e Métodos (MTM)',
      subtitle: 'Faça upload de um vídeo para iniciar a cronoanálise com IA'
    },
    reports: {
      title: 'Relatórios de Performance',
      subtitle: 'Exporte e compartilhe os resultados das suas análises'
    },
    settings: {
      title: 'Configurações e Parâmetros',
      subtitle: 'Ajuste as preferências do sistema e das análises'
    },
    saved: {
      title: 'Minhas Análises Salvas',
      subtitle: 'Visualize e gerencie seu histórico de análises'
    }
  };

  const { title, subtitle } = pageTitles[activeTab] || { title: 'EngProcess', subtitle: 'Bem-vindo' };

  return (
    <motion.div 
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="flex justify-between items-center mb-8"
    >
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">
          {title}
        </h1>
        <p className="text-blue-300/70">
          {subtitle}
        </p>
      </div>

      <div className="flex items-center gap-4">
        <Button 
          variant="outline" 
          size="icon"
          className="border-blue-500/30 text-blue-300 hover:bg-blue-600/20"
          onClick={() => toast({
            title: "🚧 Notificações em desenvolvimento",
            description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀",
            duration: 4000,
          })}
        >
          <Bell className="w-5 h-5" />
        </Button>
        <Button 
          onClick={handleCreateAnalysis}
          className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600"
        >
          <Plus className="w-5 h-5 mr-2" />
          Nova Análise
        </Button>
      </div>
    </motion.div>
  );
};

export default Header;