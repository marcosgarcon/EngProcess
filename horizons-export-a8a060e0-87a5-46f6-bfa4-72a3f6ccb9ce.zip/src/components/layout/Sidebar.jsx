import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, FileText, Settings, Zap, Target, Bot, FolderClock, UserCheck } from 'lucide-react';

const Sidebar = ({ activeTab, setActiveTab }) => {
  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'analysis', label: 'Análise MTM', icon: Bot },
    { id: 'saved', label: 'Minhas Análises', icon: FolderClock },
    { id: 'reports', label: 'Relatórios', icon: FileText },
    { id: 'settings', label: 'Configurações', icon: Settings }
  ];

  return (
    <motion.aside
      initial={{ x: -300 }}
      animate={{ x: 0 }}
      className="w-64 h-screen sidebar-gradient border-r border-blue-500/20 p-6 flex flex-col"
    >
      <div className="mb-8">
        <h1 className="text-2xl font-bold gradient-text flex items-center gap-2">
          <Zap className="w-8 h-8 text-blue-400" />
          EngProcess
        </h1>
        <p className="text-blue-300/70 text-sm mt-1">MTM - WM</p>
      </div>

      <nav className="space-y-2 flex-grow">
        {sidebarItems.map((item) => (
          <motion.button
            key={item.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
              activeTab === item.id 
                ? 'bg-blue-600/30 text-blue-300 border border-blue-500/30' 
                : 'text-blue-200/70 hover:bg-blue-600/20 hover:text-blue-300'
            }`}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </motion.button>
        ))}
      </nav>

      <div className="mt-auto pt-6 border-t border-blue-500/10">
        <div className="flex items-center gap-2 text-blue-300/60">
            <UserCheck className="w-4 h-4" />
            <div className="text-xs">
                <p className="font-semibold">Marcos Garcon</p>
                <p>Analista de Qualidade</p>
            </div>
        </div>
      </div>
    </motion.aside>
  );
};

export default Sidebar;